package com.liujiajun.service;

import com.liujiajun.po.College;

import java.util.List;


public interface CollegeService {

    List<College> finAll() throws Exception;

}
