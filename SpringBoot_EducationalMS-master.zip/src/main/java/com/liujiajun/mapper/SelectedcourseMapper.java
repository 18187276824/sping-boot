package com.liujiajun.mapper;
import com.liujiajun.po.Selectedcourse;
import com.liujiajun.po.SelectedcourseExample;
import org.apache.ibatis.annotations.Param;
import java.util.List;  /**
 * 选课Mapper接口，用于操作选课信息
 */
public interface SelectedcourseMapper {
    /**
     * 根据条件统计选课数量
     */
    int countByExample(SelectedcourseExample example);

    /**
     * 根据条件删除选课
     */
    int deleteByExample(SelectedcourseExample example);

    /**
     * 插入选课信息
     */
    int insert(Selectedcourse record);

    /**
     * 选择性插入选课信息
     */
    int insertSelective(Selectedcourse record);

    /**
     * 根据条件查询选课信息
     */
    List<Selectedcourse> selectByExample(SelectedcourseExample example);

    /**
     * 根据条件选择性更新选课信息
     */
    int updateByExampleSelective(@Param("record") Selectedcourse record, @Param("example") SelectedcourseExample example);

    /**
     * 根据条件更新选课信息
     */
    int updateByExample(@Param("record") Selectedcourse record, @Param("example") SelectedcourseExample example);
}