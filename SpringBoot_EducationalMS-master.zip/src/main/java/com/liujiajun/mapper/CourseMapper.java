package com.liujiajun.mapper;import com.liujiajun.po.Course;
import com.liujiajun.po.CourseExample;
import org.apache.ibatis.annotations.Param;import java.util.List;/**
 * 课程Mapper接口，用于操作课程信息
 */
public interface CourseMapper {    /**
 * 根据条件统计课程数量
 */
int countByExample(CourseExample example);    /**
 * 根据条件删除课程
 */
int deleteByExample(CourseExample example);    /**
 * 根据课程ID删除课程
 */
int deleteByPrimaryKey(Integer courseid);    /**
 * 插入课程信息
 */
int insert(Course record);    /**
 * 选择性插入课程信息
 */
int insertSelective(Course record);    /**
 * 根据条件查询课程信息
 */
List<Course> selectByExample(CourseExample example);    /**
 * 根据课程ID查询课程信息
 */
Course selectByPrimaryKey(Integer courseid);    /**
 * 根据条件选择性更新课程信息
 */
int updateByExampleSelective(@Param("record") Course record, @Param("example") CourseExample example);    /**
 * 根据条件更新课程信息
 */
int updateByExample(@Param("record") Course record, @Param("example") CourseExample example);    /**
 * 根据课程ID选择性更新课程信息
 */
int updateByPrimaryKeySelective(Course record);    /**
 * 根据课程ID更新课程信息
 */
int updateByPrimaryKey(Course record);
}