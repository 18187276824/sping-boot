package com.liujiajun.mapper;
import com.liujiajun.po.Userlogin;
import com.liujiajun.po.UserloginExample;
import org.apache.ibatis.annotations.Param;
import java.util.List;  /**
 * 用户登录Mapper接口，用于操作用户登录信息
 */
public interface UserloginMapper {
    /**
     * 根据条件统计用户登录数量
     */
    int countByExample(UserloginExample example);

    /**
     * 根据条件删除用户登录
     */
    int deleteByExample(UserloginExample example);

    /**
     * 根据用户ID删除用户登录
     */
    int deleteByPrimaryKey(Integer userid);

    /**
     * 插入用户登录信息
     */
    int insert(Userlogin record);

    /**
     * 选择性插入用户登录信息
     */
    int insertSelective(Userlogin record);

    /**
     * 根据条件查询用户登录信息
     */
    List<Userlogin> selectByExample(UserloginExample example);

    /**
     * 根据用户ID查询用户登录信息
     */
    Userlogin selectByPrimaryKey(Integer userid);

    /**
     * 根据条件选择性更新用户登录信息
     */
    int updateByExampleSelective(@Param("record") Userlogin record, @Param("example") UserloginExample example);

    /**
     * 根据条件更新用户登录信息
     */
    int updateByExample(@Param("record") Userlogin record, @Param("example") UserloginExample example);

    /**
     * 根据用户ID选择性更新用户登录信息
     */
    int updateByPrimaryKeySelective(Userlogin record);

    /**
     * 根据用户ID更新用户登录信息
     */
    int updateByPrimaryKey(Userlogin record);
}