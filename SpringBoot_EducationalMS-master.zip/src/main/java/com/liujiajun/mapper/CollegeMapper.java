package com.liujiajun.mapper;
import com.liujiajun.po.College;
import com.liujiajun.po.CollegeExample;
import org.apache.ibatis.annotations.Param;
import java.util.List;  /**
 * 学院Mapper接口，用于操作学院信息
 */
public interface CollegeMapper {
    /**
     * 根据条件统计学院数量
     */
    int countByExample(CollegeExample example);

    /**
     * 根据条件删除学院
     */
    int deleteByExample(CollegeExample example);

    /**
     * 根据学院ID删除学院
     */
    int deleteByPrimaryKey(Integer collegeid);

    /**
     * 插入学院信息
     */
    int insert(College record);

    /**
     * 选择性插入学院信息
     */
    int insertSelective(College record);

    /**
     * 根据条件查询学院信息
     */
    List<College> selectByExample(CollegeExample example);

    /**
     * 根据学院ID查询学院信息
     */
    College selectByPrimaryKey(Integer collegeid);

    /**
     * 根据条件选择性更新学院信息
     */
    int updateByExampleSelective(@Param("record") College record, @Param("example") CollegeExample example);

    /**
     * 根据条件更新学院信息
     */
    int updateByExample(@Param("record") College record, @Param("example") CollegeExample example);

    /**
     * 根据学院ID选择性更新学院信息
     */
    int updateByPrimaryKeySelective(College record);

    /**
     * 根据学院ID更新学院信息
     */
    int updateByPrimaryKey(College record);
}