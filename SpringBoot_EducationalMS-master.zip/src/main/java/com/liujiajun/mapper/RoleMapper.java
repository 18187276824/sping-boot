package com.liujiajun.mapper;
import com.liujiajun.po.Role;
import com.liujiajun.po.RoleExample;
import org.apache.ibatis.annotations.Param;
import java.util.List;  /**
 * 角色Mapper接口，用于操作角色信息
 */
public interface RoleMapper {
    /**
     * 根据条件统计角色数量
     */
    int countByExample(RoleExample example);

    /**
     * 根据条件删除角色
     */
    int deleteByExample(RoleExample example);

    /**
     * 根据角色ID删除角色
     */
    int deleteByPrimaryKey(Integer roleid);

    /**
     * 插入角色信息
     */
    int insert(Role record);

    /**
     * 选择性插入角色信息
     */
    int insertSelective(Role record);

    /**
     * 根据条件查询角色信息
     */
    List<Role> selectByExample(RoleExample example);

    /**
     * 根据角色ID查询角色信息
     */
    Role selectByPrimaryKey(Integer roleid);

    /**
     * 根据条件选择性更新角色信息
     */
    int updateByExampleSelective(@Param("record") Role record, @Param("example") RoleExample example);

    /**
     * 根据条件更新角色信息
     */
    int updateByExample(@Param("record") Role record, @Param("example") RoleExample example);

    /**
     * 根据角色ID选择性更新角色信息
     */
    int updateByPrimaryKeySelective(Role record);

    /**
     * 根据角色ID更新角色信息
     */
    int updateByPrimaryKey(Role record);
}