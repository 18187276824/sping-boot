package com.liujiajun.po;import java.io.Serializable;/**
 * 学院实体类
 */
public class College implements Serializable {
    private Integer collegeid; // 学院ID
    private String collegename; // 学院名称
        public Integer getCollegeid() {
        return collegeid;
        }
        public void setCollegeid(Integer collegeid) {
        this.collegeid = collegeid;
    }
    public String getCollegename() {
        return collegename;
    }
    public void setCollegename(String collegename) {
        this.collegename = collegename == null ? null : collegename.trim();
    }
    @Override
    public String toString() {
        return "College{" +
                "collegeid=" + collegeid +
                ", collegename='" + collegename + '\'' +
                '}';
    }
}