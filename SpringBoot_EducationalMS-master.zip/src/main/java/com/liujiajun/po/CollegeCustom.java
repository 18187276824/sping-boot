package com.liujiajun.po;

/**
 * College扩展类
 */
public class CollegeCustom extends College {



}
