package com.liujiajun.po;
/**
 * 用户ID检查实体类
 */
public class CheckUserId {
    private Integer userid;
    // 用户ID
    private boolean flag;
    // 用户存在返回false，用户不存在返回true
    private String errorMsg; // 错误信息
    public Integer getUserid() {
        return userid;
    }
public void setUserid(Integer userid) {
        this.userid = userid;
    }    public boolean isFlag() {
        return flag;
    }    public void setFlag(boolean flag) {
        this.flag = flag;
    }    public String getErrorMsg() {
        return errorMsg;
    }    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }    @Override
    public String toString() {
        return "CheckUserId{" +
                "userid=" + userid +
                ", flag=" + flag +
                ", errorMsg='" + errorMsg + '\'' +
                '}';
    }
}